import React,{Component} from 'react';
import {View,Text,ScrollView,TouchableOpacity} from 'react-native';
import firebase from 'firebase';
import Header from './Header2';
import Tarea from '../Components/Tarea';
import renderIf from '../renderIf';
import AgregarTarea from  './AgregarTarea';
class PantallaTareasP extends Component{
    state = {
        tareas: [],
        hide:true
    };
    componentWillMount=()=>{
        let arr = []
        const user = firebase.auth().currentUser;
        firebase.database().ref('Padres/' + user.uid + "/Tareas/").on("child_added", (snapshot, prevChildKey) => {
            let newPost = snapshot.val();
            let tarea = {
                titulo: newPost.Titulo,
                fecha: newPost.fecha,
            }
            arr.push(tarea)
        })
        this.setState({
            tareas:arr
        })
    }

    render(){
        
        let arr=this.state.tareas.map((tarea,index)=><Tarea nombre={tarea.titulo} fecha={tarea.fecha} key={index}/>)
        let titulo="Agregar tarea";
        let estilo = [{
            backgroundColor: "#0776A0",
            width: 150,
            height: 50,
            borderRadius: 5,
            alignItems: "center",
            padding: 11,
            marginTop: 20,
            marginBottom: 15
        },{color:"white",fontSize:18}];
        if(!this.state.hide){
            titulo="Regresar"
            estilo=[{marginTop:20},{textDecorationLine:"underline"}]
        }
        return(
            
            <View style={{width:"100%",height:"100%",backgroundColor:"#fafafa",alignItems:"center"}}> 
                <Header click={()=>this.props.navigation.openDrawer()}/>
                <Text style={{fontSize:24}}>Tareas</Text>
                {renderIf(this.state.hide, 
                    <View>
                        {arr}
                    </View>
                )}    
                {renderIf(!this.state.hide,
                   <AgregarTarea/>         
                )}
                <TouchableOpacity onPress={()=>this.setState({hide:!this.state.hide})}style={estilo[0]}><Text style={estilo[1]}>{titulo}</Text></TouchableOpacity>
            </View> 
        );
    }
};

export default PantallaTareasP;