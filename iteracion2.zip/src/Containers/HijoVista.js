/*
Autores:Diego Aragón,Roberto González,Alan Ricardo
Fecha de creación:04/10/2018
Fecha de ultima modificación:05/10/2018
Por quien fue modificado: Diego Aragón
Motivo de modificación: Arreglar vista con fonts grandes y margin entre los componentes
*/
import React,{Component} from 'react';
import {View,TextInput,StyleSheet,TouchableOpacity,Text,Image} from 'react-native';
import Header from './Header';
import firebase from 'firebase';
/*
    Componente principal de HijoVista.js
    Toma como props el nombre del hijo a desplegar y el nombre de su padre
*/
class HijoVista extends Component{
    render(){
        const { navigation } = this.props;//navigation es referencia a this.props
        const nombre = navigation.getParam('nombre', 'NO-ID');//Variable nombre recibe props nombre hijo
        const papa = navigation.getParam('papa', 'some default value');//Variable papa recibe props nombre de padre
        const registro = () => this.props.navigation.navigate('Registro');//funcion  para navegar a pantalla Registro
        /*
            Vista HijoVista con JSX
        */
        return(
            <View style={styles.div}>
                <Header/>
                <View style={styles.divHijoVista}>
                    <View style={{width:"100%",height:"40%",alignItems:"center"}}>
                        <Text style={{color:"black",fontSize:30,marginBottom:50}}>Vista hijo</Text>
                        <Text style={{color:"black",fontSize:40}}>Nombre:{nombre}</Text>
                        <Text style={{color:"black",fontSize:40}}>Padre:{papa}</Text>
                    </View>
                    <View style={{with:"100%",height:"60%",alignItems:"center"}}>
                        <TouchableOpacity style={styles.botonAzul} onPress={registro}><Text style={{fontSize:20,color:"white"}}>Ir a registro</Text></TouchableOpacity>
                    </View>
                </View>
            </View>
             
        );
    }
};
/*
    Hoja de estilos para JSX
*/
const styles = StyleSheet.create({
    div:{
        width:"100%",
        height:"100%",
        backgroundColor:"#fafafa",
        alignItems: "center",
        color:"#ffffff",
    },
    divHijoVista:{
        width:"100%",
        height:"85%",
        marginTop:8,
        alignItems:"center"
    },
    input:{
        width:"90%",
        height: "100%",
        fontSize:18,
        borderStyle:"solid",
        borderWidth:3,
        borderColor:"#9e9e9e",
        borderRadius: 5,
        marginBottom:10,
    },
    botonAzul: {
        backgroundColor: "#0776A0",
        width: 150,
        height: 50,
        borderRadius: 5,
        alignItems: "center",
        padding:11,
        marginTop: 20,
        marginBottom:15 
    },
               
});

export default HijoVista;