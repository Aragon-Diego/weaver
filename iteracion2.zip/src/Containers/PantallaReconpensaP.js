import React,{Component} from 'react';
import {View,Text,StyleSheet,TextInput,TouchableOpacity} from 'react-native';
import firebase from 'firebase';
import Header from './Header2';
import Recompensa from '../Components/Reconpensa';
import AgregarRecompensas from './AgregarRecompensas';

class PantallaReconpesaP extends Component{
    state = {
        recompensas: [],
        hide:true
    };
    componentWillMount=()=>{
        let arr = []
        const user = firebase.auth().currentUser;
        firebase.database().ref('Padres/' + user.uid + "/Recompensas/").on("child_added", (snapshot, prevChildKey) => {
            let newPost = snapshot.val();
            let recompensa = {
                titulo: newPost.Titulo,
                puntos: newPost.puntos,
            }
            arr.push(recompensa)
        })
        this.setState({
            recompensas: arr
        })
    }
    render(){        
        let arr=this.state.recompensas.map((recompensa,index)=><Recompensa nombre={recompensa.titulo} puntos={recompensa.puntos} key={index}/>)
        let titulo="Agregar";
        let estilo = [{
            backgroundColor: "#0776A0",
            width: 150,
            height: 50,
            borderRadius: 5,
            alignItems: "center",
            padding: 11,
            marginTop: 20,
            marginBottom: 15
        },{color:"white",fontSize:18}];
        if(!this.state.hide){
            titulo="Regresar"
            estilo=[{marginTop:20},{textDecorationLine:"underline"}]
        }
        return(
            <View style={{width:"100%",height:"100%",backgroundColor:"#fafafa",alignItems:"center"}}> 
                <Header click={()=>this.props.navigation.openDrawer()}/>
                <Text style={{fontSize:24}}>Recompensas</Text>
                {renderIf(this.state.hide, 
                    <View>
                        {arr}
                    </View>
                )}    
                {renderIf(!this.state.hide,
                   <AgregarRecompensas/>
                )}
                <TouchableOpacity onPress={()=>this.setState({hide:!this.state.hide})}style={estilo[0]}><Text style={estilo[1]}>{titulo}</Text></TouchableOpacity>
            </View> 
        );
    }
};

export default PantallaReconpesaP;