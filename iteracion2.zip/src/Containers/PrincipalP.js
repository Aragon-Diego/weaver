import React,{Component} from 'react';
import {View,Text} from 'react-native';
import firebase from 'firebase';
import Header from './Header2';
import Tarea from '../Components/Tarea';
import Recompensa from '../Components/Reconpensa';

class PrincipalPapa extends Component{
render(){
        return(
            <View style={{width:"100%",height:"100%",backgroundColor:"#fafafa",alignItems:"center"}}>
                <Header click={()=>this.props.navigation.openDrawer()}/>
                <View>
                    <Text>Principal padre</Text>
                </View>
            </View>
        );
    }
};


export default PrincipalPapa;